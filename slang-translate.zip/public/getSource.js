/* global chrome */
function get_url(){
    var newURL = window.location.protocol + "//" + window.location.host + "/" + window.location.pathname;
    console.log("current url");
    return newURL
}

const 

// chrome.extension.sendMessage({
//     action: "getSource",
//     source: get_url(document.body)
// });


// chrome.extension.onMessage.addListener(function(request, sender){
//     alert("execute");
//     if(request.action == "jsondata") {
//       var json = request.source;
//     }
// });

// chrome.extension.onMessage.addListener(function(request, sender){
//     if(request.action == "style"){
//         alert("execute");
//         const styled = request.source;
//     }
// });


function dragText() {
    console.log("mouse move");
    let text;
    if(window.getSelection) {
        text = window.getSelection().toString();
    }
    else if (document.selection) {
        text = document.selection.createRange().text;
    }
    return text;
}

document.onmouseup = function() {
    let text = dragText();
    if(text) {
        chrome.extension.sendMessage({
            action : "dragtext",
            source : dragText()
        })
    }
}

function doSearch(text) {
    let tooltip = document.createElement("span");
    let inner = document.createElement("p");
    inner.innerHTML = "new word"

    if (window.find && window.getSelection) { 
        document.designMode = "on";
        var sel = window.getSelection();
        sel.collapse(document.body, 0);
        while (window.find(text)) {
            document.execCommand("insertHTML" , false , `<span style = 'color:red'><strong>${text}</strong></span>`)
            // document.execCommand("insertHTML" , false , "<span className = 'tooltiplink' , datatooltip='new word'>new</span>")
            // document.execCommand("insertHTML" , false , `<span className = '${styled.found}' >new</span>`)
            //document.execCommand("insertHTML" , false , `<span className = ${styled.tooltiplink} >${text}</span>`)
            sel.collapseToEnd();
        }
        document.designMode = "off";
    } 
    window.scrollTo(0,0);
}

doSearch("is");
