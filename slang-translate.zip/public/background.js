/* global chrome */

console.log("background running");

