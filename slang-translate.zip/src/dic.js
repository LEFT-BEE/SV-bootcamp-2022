export default {
    "is" : "it is good",
    "love" : "it is love",
    "new" : "it is new"
};