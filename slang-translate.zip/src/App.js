/* global chrome */
import './App.css';
import React from 'react'
import dic_js from "./dic.js";
import found from "./test.css";

function rendering(){
  let cur_text = "";
  chrome.extension.onMessage.addListener(function(request, sender) {
    if(request.action == "dragtext") {
      cur_text = request.source;
      }
  });

  if(dic_js[cur_text]){
    alert(dic_js[cur_text])
    displayText(dic_js[cur_text])
  }
}


function App() {
  __onWindowLoad();
  rendering();
  return (
    <body></body>
  );
}

function __onWindowLoad() {
  function onWindowLoad() {
    chrome.tabs.executeScript(null, {
      file: "getSource.js"
      }, function() {
      if(chrome.extension.lastError) {
        document.body.innerText = 'Error : \n' + chrome.extension.lastError.message;
      }
    });
  }

  window.onload = onWindowLoad;
}

export default App;

function displayText(translated) {
  let newDIV = document.createElement("div");
  let newP = document.createElement("p");
  let closeButton = document.createElement("span");

  closeButton.innerHTML = "X";
  closeButton.addEventListener('click', function() {
      this.parentElement.style.display = "none";
  });
  newP.innerHTML = translated;

  newDIV.appendChild(closeButton);
  newDIV.appendChild(newP);

  newDIV.setAttribute("class","translatedTextView");
  newDIV.style.padding = "1rem";
  newDIV.style.position = "fixed";
  newDIV.style.zIndex = "1";
  newDIV.style.right = "0";
  newDIV.style.top = "0";
  newDIV.style.textAlign = "right";
  newDIV.style.background = "#FFFFFF";
  newDIV.style.border = "2px solid #CEECF5";
  newDIV.style.borderRadius = "1em 0 1em 1em";

  document.body.appendChild(newDIV);
}